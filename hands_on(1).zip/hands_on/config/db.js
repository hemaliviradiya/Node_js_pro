const mongoose = require('mongoose');
mongoose.connect(process.env.DBURL).then(() => {
    console.log(`database is connected`);
}).catch((error) => {
    console.log('database is not connected', error);
});
const db = mongoose.connection;
//mongoose.set('useFindAndModify', false);

db.on('error', console.error.bind(console, 'connection error:'));
module.exports = mongoose