const express = require('express');
const app = express();
const session = require("express-session")
const port = process.env.port || 8000

app.use(session({
    secret: 'secret',
    resave: false,
    saveUninitialized: false
}));

app.use(express.urlencoded({ extended: true }));

const morgan = require("morgan")
app.use(morgan("combined"))
const helmet = require("helmet")
app.use(helmet())
require('dotenv').config();
app.post("/login", (req, res) => {
    if (req.body.username == "user1" && req.body.password == "pass") {
        req.session.username == req.body.username;
        req.session.loggedin = true;
        res.status(200).send("success")
    } else {
        res.status(401).send("Not Authorized")
    }
})

function validate_session(req, res, next) {
    if (req.session.loggedin) {
        next()
    } else {
        return res.status(401).send("Not Authorized")
    }
}

const BookRoute = require("./routes/BookRouts")
app.use("/books", validate_session, BookRoute)

app.listen(port, () => {
    console.log(`server is riunnig on ${port}`);
});